package com.cg.plp.bean;

public class NewPolicyCreationBean 
{
	private String agentName;
	private String accNumber;
	private String premiumAmount;
	private String userName;
	private String busSegment;
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBusSegment() {
		return busSegment;
	}
	public void setBusSegment(String busSegment) {
		this.busSegment = busSegment;
	}
	
	
	
	
}
