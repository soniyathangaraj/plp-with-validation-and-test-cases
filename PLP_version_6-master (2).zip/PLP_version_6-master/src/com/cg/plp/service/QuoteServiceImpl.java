package com.cg.plp.service;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.plp.bean.AccountCreationBean;
import com.cg.plp.bean.PolicyBean;
import com.cg.plp.bean.PolicyCreationBean;
import com.cg.plp.bean.PolicyQuestions;
import com.cg.plp.bean.UserLoginBean;
import com.cg.plp.dao.IQuoteDAO;
import com.cg.plp.dao.QuoteDAOImpl;
import com.cg.plp.exception.InsuranceException;

public class QuoteServiceImpl implements IQuoteService {

	IQuoteDAO iQuoteDAO = new QuoteDAOImpl();

	@Override
	public int checkValidLogin(UserLoginBean userLoginBean)
			throws ClassNotFoundException, FileNotFoundException, SQLException {

		// System.out.println("id"+userLoginBean.getLoginId());

		return iQuoteDAO.checkValidLogin(userLoginBean);
	}

	@Override
	public void profileCreation(UserLoginBean userLoginBean)
			throws ClassNotFoundException, FileNotFoundException, SQLException {
		// TODO Auto-generated method stub

		// System.out.println(userLoginBean.getPassword()+"
		// "+userLoginBean.getLoginId());

		iQuoteDAO.profileCreation(userLoginBean);

	}

	@Override
	public void accountCreation(AccountCreationBean accountCreationBean)
			throws ClassNotFoundException, FileNotFoundException, SQLException {
		// TODO Auto-generated method stub
		iQuoteDAO.accountCreation(accountCreationBean);
	}

	@Override
	public void policyCreation(PolicyCreationBean policyCreationBean)
			throws ClassNotFoundException, FileNotFoundException, SQLException {
		// TODO Auto-generated method stub
		iQuoteDAO.policyCreation(policyCreationBean);

	}

	@Override
	public List<PolicyQuestions> retrieveAll() throws ClassNotFoundException, FileNotFoundException, SQLException {

		// List<PolicyQuestions> policyList=null;
		List<PolicyQuestions> policy = new ArrayList<PolicyQuestions>();
		policy = iQuoteDAO.retrieveAll();

		return policy;

		// public List<DonorBean> retriveAll() throws DonorException {
		// donorDao=new DonorDaoImpl();
		// List<DonorBean> donorList=null;
		// donorList=donorDao.retriveAllDetails();
		// return donorList;
	}

	@Override
	public List<PolicyBean> getMyPolicies(String userName)
			throws ClassNotFoundException, FileNotFoundException, SQLException {
		iQuoteDAO = new QuoteDAOImpl();
		List<PolicyBean> li = new ArrayList<>();
		li = iQuoteDAO.getMyPolicies(userName);
		return li;
	}

	@Override
	public List<PolicyBean> getMyCustomerPolicies(int agentId)
			throws ClassNotFoundException, FileNotFoundException, SQLException, InsuranceException {
		iQuoteDAO = new QuoteDAOImpl();
		List<PolicyBean> li = new ArrayList<PolicyBean>();
		li = iQuoteDAO.getMyCustomerPolicies(agentId);
		return li;
	}

	public boolean validateAccountCreation(AccountCreationBean accountCreationBean) throws InsuranceException {
		// TODO Auto-generated method stub

		List<String> validationErrors = new ArrayList<String>();

		if (!(isValidName(accountCreationBean.getInsuredName()))) {
			validationErrors.add("Insured Name should be in Alphabets and minimum 3 characters long\n");
		}
		if (!(isValidStreetName(accountCreationBean.getInsuredStreet()))) {
			validationErrors.add("Insured street Address should be greater than 5 characters long\n");
		}
		if (!(isValidCity(accountCreationBean.getInsuredCity()))) {
			validationErrors.add("Insured city Address should be greater than 5 characters long\n");
		}
		if (!(isValidState(accountCreationBean.getInsuredState()))) {
			validationErrors.add("Insured state Address should be greater than 5 characters long\n");
		}
		if (!(isValidZip(accountCreationBean.getInsuredZip()))) {
			validationErrors.add("zip should be 5 digit number\n");
		}
		if (!(validationErrors.isEmpty())) {
			throw new InsuranceException(validationErrors + " ");
		}

		return true;

	}

	private boolean isValidName(String insuredName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredName);
		return nameMatcher.matches();
	}

	private boolean isValidState(String insuredState) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredState);
		return nameMatcher.matches();
	}

	private boolean isValidCity(String insuredCity) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredCity);
		return nameMatcher.matches();
	}

	private boolean isValidStreetName(String insuredStreet) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredStreet);
		return nameMatcher.matches();
	}

	private boolean isValidZip(int insuredZip) {
		String insured_zip = String.valueOf(insuredZip);
		Pattern zipPattern = Pattern.compile("^[1-9]{1}[0-9]{4}$");
		Matcher zipMatcher = zipPattern.matcher(insured_zip);
		return zipMatcher.matches();
	}

	public boolean validatePolicyCreation(PolicyCreationBean policyCreationBean) throws InsuranceException {
		// TODO Auto-generated method stub

		List<String> validationErrors = new ArrayList<String>();

		if (!(isValidName(policyCreationBean.getInsuredName()))) {
			validationErrors.add("Insured Name should be in Alphabets and minimum 3 characters long\n");
		}
		if (!(isValidStreetName(policyCreationBean.getInsuredStreet()))) {
			validationErrors.add("Insured street Address should be greater than 5 characters long\n");
		}
		if (!(isValidCity(policyCreationBean.getInsuredCity()))) {
			validationErrors.add("Insured city Address should be greater than 5 characters long\n");
		}
		if (!(isValidState(policyCreationBean.getInsuredState()))) {
			validationErrors.add("Insured state Address should be greater than 5 characters long\n");
		}
		if (!(isValidState(policyCreationBean.getAgentName()))) {
			validationErrors.add(" Agent Name should be in Alphabets and minimum 3 characters long\n");
		}
		if (!(isValidZip(policyCreationBean.getInsuredZip()))) {
			validationErrors.add("zip should be 5 digit number\n");
		}
		if (!(validationErrors.isEmpty())) {
			throw new InsuranceException(validationErrors + " ");
		}
		return true;

	}

	private boolean isValidName1(String insuredName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredName);
		return nameMatcher.matches();
	}

	private boolean isValidState1(String insuredState) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredState);
		return nameMatcher.matches();
	}

	private boolean isValidCity1(String insuredCity) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredCity);
		return nameMatcher.matches();
	}

	private boolean isValidStreetName1(String insuredStreet) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(insuredStreet);
		return nameMatcher.matches();
	}

	private boolean isValidAgenmtName(String agentName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(agentName);
		return nameMatcher.matches();
	}

	private boolean isValidZip1(int insuredZip) {
		String insured_zip = String.valueOf(insuredZip);
		Pattern zipPattern = Pattern.compile("^[1-9]{1}[0-9]{4}$");
		Matcher zipMatcher = zipPattern.matcher(insured_zip);
		return zipMatcher.matches();
	}

}
