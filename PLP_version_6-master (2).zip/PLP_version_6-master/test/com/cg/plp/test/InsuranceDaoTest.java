package com.cg.plp.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.plp.bean.AccountCreationBean;
import com.cg.plp.bean.BusinessSegmentBean;
import com.cg.plp.bean.PolicyBean;
import com.cg.plp.bean.PolicyCreationBean;
import com.cg.plp.bean.UserLoginBean;
import com.cg.plp.dao.QuoteDAOImpl;
import com.cg.plp.exception.InsuranceException;

class InsuranceDaoTest {
	static QuoteDAOImpl dao;
	static AccountCreationBean accountCreationBean;
	static BusinessSegmentBean businesssegmentBean;
	static PolicyCreationBean policyCreationBean;
	static PolicyBean policyBean;
	static UserLoginBean userLoginBean;
	
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new QuoteDAOImpl();
		accountCreationBean=new AccountCreationBean ();
		businesssegmentBean=new BusinessSegmentBean();
		policyBean=new PolicyBean();
		policyCreationBean=new PolicyCreationBean();
		userLoginBean=new UserLoginBean();
		
		
	}

	@Test
	
     public void checkValidLogin()  throws InsuranceException, ClassNotFoundException, FileNotFoundException, SQLException {
		
		assertNotNull(dao.checkValidLogin(userLoginBean));
		
	}
	
	@Test
	public void profileCreation() throws InsuranceException
	{
		assertNotNull(dao.profileCreation(userLoginBean));
	}
	
	

	@Test
	public void accountCreation() throws InsuranceException, NumberFormatException, ClassNotFoundException, FileNotFoundException, SQLException {

		accountCreationBean.setInsuredName("Shashwathi");
		accountCreationBean.setInsuredStreet("Navalur");
		accountCreationBean.setInsuredCity("Kanchipuram");
		accountCreationBean.setInsuredState("Tamilnadu");
		accountCreationBean.setInsuredZip(60001);
		accountCreationBean.setBusinessSegment("vehicle");
		accountCreationBean.setAccountNo(12365498);
		
		
		assertTrue("Data Inserted successfully",
				Double.parseDouble(dao.accountCreation(accountCreationBean)) );// account number should be placed.
				

	}
	
	@Test
	public void policyCreation(PolicyCreationBean policyCreationBean)throws InsuranceException{
		
		
		policyCreationBean.setInsuredName("Suganya");
		policyCreationBean.setInsuredStreet("Navalur");
		policyCreationBean.setInsuredCity("Kanchipuram");
		policyCreationBean.setInsuredState("Tamilnadu");
		policyCreationBean.setInsuredZip(60005);
		policyCreationBean.setBusinessSegment("Shop");
		policyCreationBean.setPolicyPremium(1000);
		policyCreationBean.setAgentName("Thangaraj");
		policyCreationBean.setAccountNo(12345687);
		
		
		assertTrue("Data Inserted successfully",
				Double.parseDouble(dao.policyCreation(policyCreationBean)));// incomplete
	
	}
	@Test
	public void testViewPolicy() throws InsuranceException, ClassNotFoundException, FileNotFoundException, SQLException {
		assertNotNull(dao.getMyPolicies("Suganya")); // view my ploicy
	}
	@Test
	public void testViewAll() throws InsuranceException, ClassNotFoundException, FileNotFoundException, SQLException {
		assertNotNull(dao.getMyCustomerPolicies(1));// agent id should be placed (1)
	}


}
